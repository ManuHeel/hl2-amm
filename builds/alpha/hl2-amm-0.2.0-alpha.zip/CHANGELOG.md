# Half-Life 2 Adaptive Music Mod - Changelog

## 0.2.0-alpha
### General
### Engine
- Refactor the whole codebase to replace c-style const char strings with std::string
- Fixed a bug causing crashes when saving the game
- Add support for EntitySequenceWatcher
- Add support for ScriptedSequenceWatcher
- Add support for TriggerWatcher
- Standardize debug console print info
### Music

## 0.1.0-alpha
### General
- First Alpha release
### Engine
- Basic FMOD integration provided through the SourceMod extension
- Basic Adaptive Music integration provided through the SourceMod plugin
### Music
- d1_trainstation_02 runs on a first draft of music
- d1_trainstation_03 is empty
- d1_trainstation_05 runs on a test music
- d1_canals_01 runs on a test music