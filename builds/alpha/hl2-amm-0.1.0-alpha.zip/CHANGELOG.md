# Half-Life 2 Adaptive Music Mod - Changelog

## 0.1.0-alpha
### General
- First Alpha release
### Engine
- Basic FMOD integration provided through the SourceMod extension
- Basic Adaptive Music integration provided through the SourceMod plugin
### Music
- d1_trainstation_02 runs on a first draft of music
- d1_trainstation_03 is empty
- d1_trainstation_05 runs on a test music
- d1_canals_01 runs on a test music